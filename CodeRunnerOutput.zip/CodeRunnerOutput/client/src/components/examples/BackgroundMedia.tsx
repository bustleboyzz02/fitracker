import { BackgroundMedia } from '../BackgroundMedia';

export default function BackgroundMediaExample() {
  return <BackgroundMedia gradient />;
}
